# Objective

> This pop up a calendar where you may simply click on to select a date.

## Update notes

* [ ] Need new display layout (there some good options on watchlater on youtube)
* [ ] Open with today already selected (not as a value but the button itself)


